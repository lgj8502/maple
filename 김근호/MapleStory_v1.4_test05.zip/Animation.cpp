#include "stdafx.h"
#include "Animation.h"

void Animation::Update(float _DelayTime)
{
	m_ElapseTime += _DelayTime;

	if (m_ElapseTime > m_AniTime[m_NowFrame])
	{
		m_ElapseTime -= m_AniTime[m_NowFrame];

		m_NowFrame = (m_NowFrame + 1) % m_MaxFrame;
	}
}
