#include "stdafx.h"
#include "Image.h"

Image::Image()
{
}

BOOL Image::AddImg(LPCWSTR _FilePath)
{
	/*Image t_ImgInfo;

*/
	return 0;
}

ID2D1Bitmap * Image::ImageAsBitmap(LPCWSTR _FilePath)
{
	return nullptr;
}

Image::~Image()
{
}

void Image::FileFindDir(wstring _Path)
{
}

VOID Image::Render()
{

	if (m_Bitmap == nullptr)
	{
		return;
	}

	auto Size = m_Bitmap->GetSize();

	m_ImgRT.left = -Size.width / 2;
	m_ImgRT.right = +Size.width / 2;
	m_ImgRT.top = -Size.height / 2;
	m_ImgRT.bottom = Size.height / 2;

	m_pRT->DrawBitmap(m_Bitmap, m_ImgRT);
	return VOID();
}

VOID Image::Render(wstring _bitmapName)
{
	if (m_Bitmap == nullptr || m_Name != _bitmapName)
	{

		return;
	}
	auto Size = m_Bitmap->GetSize();

	m_ImgRT.left = -Size.width / 2;
	m_ImgRT.right = +Size.width / 2;
	m_ImgRT.top = -Size.height / 2;
	m_ImgRT.bottom = Size.height / 2;

	m_pRT->DrawBitmap(m_Bitmap, m_ImgRT);
	return VOID();
}

VOID Image::Render(wstring _bitmapName, D2D1_RECT_F _rt)
{
	if (m_Bitmap == nullptr || m_Name != _bitmapName)
	{
		return;
	}
	//MessageBoxA(nullptr, "��������� ����2", "����", MB_OK);
	m_pRT->SetTransform(m_matSRT);
	m_ImgRT = _rt;
	m_pRT->DrawBitmap(m_Bitmap, m_ImgRT);
	return VOID();
}

VOID Image::SetRenderTarget(ID2D1HwndRenderTarget * _rt)
{
	m_pRT = _rt;
	return VOID();
}

VOID Image::SetID2D1Bitmap(ID2D1Bitmap * _ID2D1Bitmap)
{
	m_Bitmap = _ID2D1Bitmap;
	return VOID();
}
