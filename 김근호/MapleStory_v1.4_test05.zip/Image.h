#pragma once
#include "TemplateSingleton.h"
#include "WICImg.h"
#include <map>

class Image : public Object
{
public:
	wstring m_Name;
	wstring m_Path;
	ID2D1Bitmap *m_Bitmap = nullptr;
	D2D1_RECT_F				m_ImgRT = {};
	ID2D1HwndRenderTarget	*m_pRT = nullptr;
public:
	Image();
	BOOL AddImg(LPCWSTR _FilePath);

	ID2D1Bitmap *ImageAsBitmap(LPCWSTR _FilePath);
	~Image();
	void FileFindDir(wstring _Path);

	VOID Render();
	VOID Render(wstring _bitmapName);
	VOID Render(wstring _bitmapName, D2D1_RECT_F _rt);
	void	 Update(float _DelayTime = 0.0f) {}

	VOID SetRenderTarget(ID2D1HwndRenderTarget *_rt);
	VOID SetID2D1Bitmap(ID2D1Bitmap *_ID2D1Bitmap);
	ID2D1Bitmap *GetID2D1Bitmap()
	{
		return m_Bitmap;
	}
	wstring Getm_Name() 
	{
		return m_Name;
	}
	VOID Setm_Name(wstring _m_Name)
	{
		m_Name = _m_Name;
	}

	wstring Getm_Path()
	{
		return m_Path;
	}
	VOID Setm_Path(wstring _m_Path)
	{
		m_Path = _m_Path;
	}
};

