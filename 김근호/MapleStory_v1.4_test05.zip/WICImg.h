#pragma once

//WIC (Windows Image Component)
#include <wincodec.h>

#include"Object.h"

class WICImg
	: public Object
{
private:
	IWICImagingFactory		*m_pIWICFactory				= nullptr;
	IWICFormatConverter		*m_pConvertedSourceBitmap	= nullptr;


	
	D2D1_RECT_F				m_ImgRT						= {};
	D2D1_POINT_2L			m_Frame						= {};

public:
	ID2D1Bitmap				*m_D2D1Bitmap = nullptr;

public:
	WICImg();
	~WICImg();

	void	Update(float _DelayTime = 0.0f);
	void	Render();
	void	Render(int _FrameX, int _FrameY = 0);

	HRESULT ResetDevice(ID2D1HwndRenderTarget *_pRT = nullptr);
	void	LostDevice();

	HRESULT	LoadImg(LPCWSTR _FilePath);
	////////////////////////////////////////////////////////////////////
	void	SetFrame(int _x, int _y = 1)
	{
		m_Frame.x = _x;
		m_Frame.y = _y;
	}
	
	ID2D1Bitmap*	GetBitmap()
	{
		return m_D2D1Bitmap;
	}
};

