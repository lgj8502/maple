#pragma once
class Animation
{
public:
	int					m_NowFrame = 0;
	int					m_MaxFrame = 0;
	FLOAT				m_ElapseTime = 0;

	std::vector<FLOAT>	m_AniTime;

	void	SetFrame(int _Max)
	{
		m_MaxFrame = _Max;
		m_AniTime.resize(m_MaxFrame);
	}

	void	SetAniTime(int _Index, FLOAT _Time)
	{
		m_AniTime[_Index] = _Time;
	}

	void	Update(float _DelayTime = 0);

};

