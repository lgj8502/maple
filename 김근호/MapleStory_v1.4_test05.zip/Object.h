#pragma once

#define	GET_SET_MEMBER(x, type)						\
protected:											\
type	m_##x;										\
public:												\
type	Get##x()		{	return m_##x;	}		\
void	Set##x(type _x) {	m_##x = _x;		}

#include <d2d1.h>
using D2D1::Matrix3x2F;

class Object
{
protected:
	D2D1_POINT_2F	m_Scale		= { 1,  1 };	//	ũ��
	float			m_Angle		= 0.0f;			//	Z�� ȸ����
	D2D1_POINT_2F	m_Pos		= { 0,  0 };	//	��ġ
	D2D1_POINT_2F	m_Pivot		= { 0,  0 };
	D2D1_POINT_2F	m_vDir		= { 0, -1 };	//	��ü�� �ٶ󺸴� ����
	
	Matrix3x2F		m_matScale	= Matrix3x2F::Identity();
	Matrix3x2F		m_matRot	= Matrix3x2F::Identity();
	Matrix3x2F		m_matTrans	= Matrix3x2F::Identity();
	Matrix3x2F		m_matSRT	= Matrix3x2F::Identity();

	//	D2D1 ��
	ID2D1HwndRenderTarget *m_pRT = nullptr;

protected:
	//	���� ����
	void	UpdateDir();
	//	��� ����
	void	UpdateMatrix(ID2D1HwndRenderTarget *_pRT = nullptr);
public:
	virtual ~Object() = default;

	virtual void	Update(float _DelayTime = 0.0f)						= 0;
	virtual void	Render()											= 0;
	//virtual HRESULT ResetDevice(ID2D1HwndRenderTarget *_pRT = nullptr)	= 0;
	//virtual void	LostDevice()										= 0;

	///////////////////////////////////////////////////////////////////////
	void	SetScale(float _x, float _y)
	{
		m_Scale.x = _x;
		m_Scale.y = _y;
	}
	void	SetPos(float _x, float _y)
	{
		m_Pos.x = _x;
		m_Pos.y = _y;
	}
	D2D1_POINT_2F	GetPos()
	{
		return m_Pos;
	}
	float			GetAngle()
	{
		return m_Angle;
	}
};

