#include "stdafx.h"
#include "WICImg.h"

HRESULT WICImg::LoadImg(LPCWSTR _FilePath)
{
	HRESULT hr = S_OK;

	// Create a decoder
	IWICBitmapDecoder *pDecoder = nullptr;

	hr = m_pIWICFactory->CreateDecoderFromFilename(
		_FilePath,                      // Image to be decoded
		nullptr,                         // Do not prefer a particular vendor
		GENERIC_READ,                    // Desired read access to the file
		WICDecodeMetadataCacheOnDemand,  // Cache metadata when needed
		&pDecoder                        // Pointer to the decoder
	);

	// Retrieve the first frame of the image from the decoder
	IWICBitmapFrameDecode *pFrame = nullptr;

	if (SUCCEEDED(hr))
	{
		hr = pDecoder->GetFrame(0, &pFrame);
	}

	//Step 3: Format convert the frame to 32bppPBGRA
	if (SUCCEEDED(hr))
	{
		hr = m_pIWICFactory->CreateFormatConverter(&m_pConvertedSourceBitmap);
	}

	if (SUCCEEDED(hr))
	{
		hr = m_pConvertedSourceBitmap->Initialize(
			pFrame,                          // Input bitmap to convert
			GUID_WICPixelFormat32bppPBGRA,   // Destination pixel format
			WICBitmapDitherTypeNone,         // Specified dither pattern
			nullptr,                         // Specify a particular palette 
			0.f,                             // Alpha threshold
			WICBitmapPaletteTypeCustom       // Palette translation type
		);
	}

	if (pDecoder != nullptr)
	{
		pDecoder->Release();
		pDecoder = nullptr;
	}
	if (pFrame != nullptr)
	{
		pFrame->Release();
		pFrame = nullptr;
	}

	return hr;
}

WICImg::WICImg()
{
	//	WIC �ɼ� �ѱ�
	CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);

	// Create WIC factory
	CoCreateInstance(
		CLSID_WICImagingFactory,
		nullptr,
		CLSCTX_INPROC_SERVER,
		IID_PPV_ARGS(&m_pIWICFactory));
}


WICImg::~WICImg()
{
	if (m_D2D1Bitmap != nullptr)
	{
		m_D2D1Bitmap->Release();
		m_D2D1Bitmap = nullptr;
	}
	if (m_pConvertedSourceBitmap != nullptr)
	{
		m_pConvertedSourceBitmap->Release();
		m_pConvertedSourceBitmap = nullptr;
	}
	if (m_pIWICFactory != nullptr)
	{
		m_pIWICFactory->Release();
		m_pIWICFactory = nullptr;
	}

	//	WIC Factory UnInit
	CoUninitialize();
}

void WICImg::Update(float _DelayTime)
{
	///////////////////////////////////////////

	//if (GetKeyState('A') & 0x8000)
	//{
	//	m_Angle -= 5;
	//}
	//if (GetKeyState('D') & 0x8000)
	//{
	//	m_Angle += 5;
	//}
	//if (GetKeyState('W') & 0x8000)
	//{
	//	m_Pos.x += m_vDir.x;
	//	m_Pos.y += m_vDir.y;
	//}
	//if (GetKeyState('S') & 0x8000)
	//{
	//	m_Pos.x -= m_vDir.x;
	//	m_Pos.y -= m_vDir.y;
	//}

	///////////////////////////////////////////


	UpdateMatrix();
}

void WICImg::Render()
{
	if (m_D2D1Bitmap == nullptr)	return;

	// ����� ����Ÿ�Ͽ� �����Ѵ�.
	m_pRT->SetTransform(m_matSRT);

	m_pRT->DrawBitmap(
		m_D2D1Bitmap, 
		m_ImgRT, 
		1.0f, 
		D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
		m_ImgRT);
}

void WICImg::Render(int _FrameX, int _FrameY)
{
	if (m_D2D1Bitmap == nullptr)	return;

	// ����� ����Ÿ�Ͽ� �����Ѵ�.
	m_pRT->SetTransform(m_matSRT);

	FLOAT FrameWidth	= m_ImgRT.right;
	FLOAT FrameHeight	= m_ImgRT.bottom;

	D2D1_RECT_F	SrcRT =
	{
		FrameWidth	* _FrameX,
		FrameHeight	* _FrameY,
		FrameWidth	* (_FrameX+1),
		FrameHeight	* (_FrameY+1),
	};

	m_pRT->DrawBitmap(
		m_D2D1Bitmap,
		m_ImgRT,
		1.0f,
		D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
		SrcRT);
}

HRESULT WICImg::ResetDevice(ID2D1HwndRenderTarget * _pRT)
{
	HRESULT hr = S_OK;

	if (_pRT == nullptr) return E_FAIL;

	hr = _pRT->CreateBitmapFromWicBitmap(
		m_pConvertedSourceBitmap, 
		nullptr, 
		&m_D2D1Bitmap);

	if (SUCCEEDED(hr))
	{
		auto Size = m_D2D1Bitmap->GetSize();

		m_Pivot.x = Size.width / 2;
		m_Pivot.y = Size.height / 2;
		
		m_ImgRT.left	= 0;
		m_ImgRT.right	= Size.width / m_Frame.x;
		m_ImgRT.top		= 0;
		m_ImgRT.bottom	= Size.height / m_Frame.y;

		m_Pivot.x /= m_Frame.x;
		m_Pivot.y /= m_Frame.y;

		m_pRT = _pRT;
	}

	return hr;
}

void WICImg::LostDevice()
{
	if (m_D2D1Bitmap != nullptr)
	{
		m_D2D1Bitmap->Release();
		m_D2D1Bitmap = nullptr;
	}
}
