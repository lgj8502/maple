#include "stdafx.h"
#include "IngameScene.h"

IngameScene::~IngameScene()
{
	delete m_player;

	m_player = nullptr;
}

void IngameScene::Init(HWND hWnd)
{
	m_Font.SetFont(L"����");

	m_player = new cPlayer;

	m_player->SetImgName(L"test1");
	m_player->SetScale(0.3f, 0.3f);

	m_player->SetPos(500, 500);
}

void IngameScene::Update(float _DelayTime)
{
	m_player->Update();

	if (GetKeyState(VK_F1) & 0x8000)
	{
		m_player->ChangeImg(L"test2");

	}
}

void IngameScene::Render(ID2D1HwndRenderTarget *_pRT, ID2D1SolidColorBrush *_pBrush)
{
	m_Font.TextRender(_pRT, _pBrush, Point2F(20, 20), "�ΰ��Ӿ�");

	m_player->Render();


}

LRESULT IngameScene::MyWndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage)
	{
	case WM_MOUSEMOVE:
	{
		m_MousePos.x = GET_X_LPARAM(lParam);
		m_MousePos.y = GET_Y_LPARAM(lParam);
	}break;
	case WM_LBUTTONDOWN:
	{
		SCENE_MGR->ChangeScene(SCENE_SERVER);
		Log_MGR("���Ӿ����� Ŭ����");
	}break;

	}

	return (DefWindowProcA(hWnd, iMessage, wParam, lParam));
}
