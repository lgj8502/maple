#pragma once

#include"Object.h"

class cPlayer : public Object
{
private :
	// �̹���
	ID2D1Bitmap *m_Bitmap = nullptr;
	D2D1_RECT_F	 m_ImgRT = {};


	wstring m_ImgName;

private :

	void SetImg();

public:
	cPlayer();
	~cPlayer();

	void	SetImgName(wstring _name);
	void	ChangeImg(wstring _name);

	void	Update(float _DelayTime = 0.0f);
	void	Render();

};

