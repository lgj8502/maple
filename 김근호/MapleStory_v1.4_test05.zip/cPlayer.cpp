#include "stdafx.h"
#include "cPlayer.h"


void cPlayer::SetImg()
{
	m_pRT = IMG_MGR->GetRT();

	m_Bitmap = IMG_MGR->GetImage(m_ImgName);

	if (m_Bitmap == nullptr)
	{
		ERROR_MSG("��Ʈ�� ����");
		return;
	}

	auto Size = m_Bitmap->GetSize();

	m_ImgRT.left = -Size.width / 2;
	m_ImgRT.right = +Size.width / 2;
	m_ImgRT.top = -Size.height / 2;
	m_ImgRT.bottom = Size.height / 2;
}

cPlayer::cPlayer()
{	


}


cPlayer::~cPlayer()
{
}

void cPlayer::SetImgName(wstring _name)
{
	m_ImgName = _name;
}

void cPlayer::ChangeImg(wstring _name)
{
	m_ImgName = _name;

	SetImg();

}

void cPlayer::Update(float _DelayTime)
{


	if (GetKeyState(VK_LEFT) & 0x8000)
	{
		m_Pos.x -= 5;
	}
	if (GetKeyState(VK_RIGHT) & 0x8000)
	{
		m_Pos.x += 5;
	}

	if (GetKeyState(VK_SPACE) & 0x8000)
	{
		/*

		����();

		*/
	}


	UpdateMatrix();
}

void cPlayer::Render()
{
	if (m_Bitmap == nullptr)
	{
		SetImg();
	}

	m_matSRT;

	m_pRT->SetTransform(m_matSRT);

	m_pRT->DrawBitmap(
		m_Bitmap,
		m_ImgRT);

}


