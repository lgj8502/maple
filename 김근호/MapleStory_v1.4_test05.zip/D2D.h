#pragma once

#include "Text2D.h"
#include "WICImg.h"
#include "Animation.h"



class D2D
{
	ID2D1Factory			*m_pD2DFactory = nullptr;
	ID2D1HwndRenderTarget	*m_pRT = nullptr;
	ID2D1SolidColorBrush	*m_pBrush = nullptr;

	Text2D			m_Font;	

public:
	D2D();
	~D2D();

	HRESULT	ResourceSetting(HWND _hWnd);

	HRESULT	InitBase();

	VOID	Release();

	VOID	Update(float _DelayTime);

	VOID	Render(HWND _hWnd);

	LRESULT MyWndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

};

