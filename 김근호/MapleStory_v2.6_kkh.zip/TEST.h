#pragma once
class TEST : public Object2D
{
public:
	TEST();
	~TEST();
};

