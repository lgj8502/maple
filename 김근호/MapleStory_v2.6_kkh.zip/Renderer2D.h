#pragma once

#include <vector>

#define	GET_SET_MEMBER(type, x, init)						\
protected:											\
type	m_##x = init;										\
public:												\
type	Get##x()		{	return m_##x;	}		\
void	Set##x(type _##x) {	m_##x = _##x;		}


//struct Image {
//	D2D1_RECT_F		m_ImgRT;
//	ID2D1Bitmap		*m_Bitmap;
//};

class Renderer2D
{
	GET_SET_MEMBER(int, BitmapIndex, 0);
	GET_SET_MEMBER(float, Alpha, 1.0f);
	
private:

	vector<D2D1_RECT_F>		m_ImgRTList;

	vector<ID2D1Bitmap*>    m_BitmapList;

	//vector<Image> ImageList;
public:

	Renderer2D();
	~Renderer2D();

	void Render(Matrix3x2F _mat, ID2D1RenderTarget *_pRT);

	void AddBitmap(ID2D1Bitmap* _bitmap);
	void ChangeBitmap(size_t _index);

	inline void ClearBitmap()
	{
		m_BitmapList.clear();
	}

	inline void EraseBitmap(int _index)
	{
		m_BitmapList.erase(m_BitmapList.begin() + _index);
	}

	inline void SetImgRT(D2D1_RECT_F _rt)
	{
		m_ImgRTList[m_BitmapIndex] = _rt;

	}
	inline D2D1_RECT_F GetImgRT()
	{
		return m_ImgRTList[m_BitmapIndex];
	}


};