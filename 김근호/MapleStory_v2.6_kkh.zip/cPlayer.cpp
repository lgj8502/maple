#include "stdafx.h"
#include "cPlayer.h"
//enum state
//{
//	IDLE, //stand
//	WORK, 
//	FLY,
//	LADDER
//};

cPlayer::cPlayer()
{

	//idle
	m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mushmom_stand0"));
	m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mushmom_stand1"));

	//WORK,
	m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mushmom_work0"));
	m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mushmom_work1"));
	m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mushmom_work2"));
	//	FLY,
	m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mushmom_fly0"));
	m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mushmom_fly1"));
	//	LADDER

	m_Transform.SetPos({ 500 ,500 });
}


cPlayer::~cPlayer()
{
}

//void cPlayer::Render(float _DelayTime)
//{
//	int timeCase = _DelayTime / 10;
//	switch (timeCase)
//	{
//	case IDLE:
//	{
//		
//	}
//		break;
//	case WORK:
//	{
//	
//	}
//		break;
//	case FLY:
//		break;
//	case LADDER:
//		break;
//	default:
//		break;
//	}
//}
