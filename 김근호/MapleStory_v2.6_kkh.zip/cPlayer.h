#pragma once
#include "stdafx.h"
#include <string>
enum state
{
	IDLE0, // 0 ~ 1
	IDLE1,
	WORK0, // 3~5
	WORK1,
	WORK2,
	FLY0,
	FLY1,
	LADDER
};

class cPlayer : public Object2D
{
public: 
	cPlayer();
	~cPlayer();
	int index; 
	int state = IDLE0;
	float timer;



	void Render(){

		timer = timer + 2;
		switch ((int)timer)
		{
		case 0:	state = IDLE0; break;
		case 50:	state = IDLE1; break;
		//case 100:	state = WORK0; break;
		//case 150:	state = WORK1; break;
		//case 200:	state = WORK2; break;
		//case 250:	state = FLY0; break;
		//case 300:	state = FLY1; break;
		case 100: timer = 0;  state = IDLE0; break;
		}



		//////////////////////////////////////

		switch (state)
		{
		case IDLE0:
		{
			m_Renderer.ChangeBitmap(0);
		}
		break;
		case IDLE1:
		{
			m_Renderer.ChangeBitmap(1);
		}
		break;
		case WORK0:
		{
			m_Renderer.ChangeBitmap(2);
		}
		break;
		case WORK1:
		{
			m_Renderer.ChangeBitmap(3);
		}
		break;
		case WORK2:
		{
			m_Renderer.ChangeBitmap(4);
		}
		break;
		case FLY0:
		{
			m_Renderer.ChangeBitmap(5);
		}
		break;
		case FLY1:
		{
			m_Renderer.ChangeBitmap(6);
		}
		break;
		}//switch 


		////////////

	/*	timer = timer + 1;

		if (timer == 0)
		{
			timer = 0;
		}

		if (timer <50)
		{
			m_Renderer.ChangeBitmap(0);
			m_Renderer.SetImgRT({ 500,500 });
			m_Transform.SetScale(0.3f, 0.3f);
			m_Transform.SetPos({ 5 ,500 });
			m_Renderer.Render(m_Transform.m_matSRT, m_pRT);
		}
		else if (timer >= 50)
		{
			m_Renderer.ChangeBitmap(1);
			m_Renderer.SetImgRT({ 500,500 });
			m_Transform.SetScale(0.3f, 0.3f);
			m_Transform.SetPos({ 5 ,500 });
			m_Renderer.Render(m_Transform.m_matSRT, m_pRT);
		}*/
		/////////
		m_Renderer.SetImgRT({ 500,500 });
		m_Transform.SetScale(0.3f, 0.3f);
		// �̵�
		D2D1_POINT_2F nowPos = m_Transform.GetPos();

		if (GetKeyState(VK_LEFT) & 0x8000)
		{
			m_Transform.SetPos({ nowPos.x--, nowPos.y });
		}

		if (GetKeyState(VK_RIGHT) & 0x8000)
		{
			m_Transform.SetPos({ nowPos.x++, nowPos.y });
		}

		if (GetKeyState(VK_UP) & 0x8000)
		{
			m_Transform.SetPos({ nowPos.x, nowPos.y-- });
		}

		if (GetKeyState(VK_DOWN) & 0x8000)
		{
			m_Transform.SetPos({ nowPos.x, nowPos.y++ });
		}
		//m_Transform.SetPos({ 500 ,500 });
	
		m_Renderer.Render(m_Transform.m_matSRT, m_pRT);
	}
	
};

