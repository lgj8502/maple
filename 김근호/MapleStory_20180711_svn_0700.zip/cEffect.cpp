#include "stdafx.h"
#include "cEffect.h"


cEffect::cEffect()
{
}


cEffect::~cEffect()
{
}
