#pragma once
class cArcana : public cMap
{
public:
	~cArcana();

	D2D1_POINT_2F m_Portal_1_Pos = {100, 585};

	void Init();
};

