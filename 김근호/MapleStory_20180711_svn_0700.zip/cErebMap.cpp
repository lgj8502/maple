#include "stdafx.h"
#include "cErebMap.h"

cErebMap::~cErebMap()
{
	Destroy();
}

void cErebMap::Init()
{
	IMG_MGR->FileFindDir_Take(L".\\Img\\map\\Ereb\\", m_MapImgList);

	// ���� �� ��� 1

	MAP_MGR->AddBackGround1_Back1();

	// ����ó�� ��ũ�� �Ǵ� ��

	MAP_MGR->AddScroll(L"back.2", { 200.0f,150.0f });
	MAP_MGR->AddScroll(L"back.3", { 200.0f, 100.0f });
	MAP_MGR->AddScroll(L"back.4", { 350.0f, 70.0f });
	MAP_MGR->AddScroll(L"back.6", { 400.0f, 80.0f });
	MAP_MGR->AddScroll(L"back.7", { 600.0f, 90.0f });
	MAP_MGR->AddScroll(L"back.8", { 750.0f, 40.0f });
	MAP_MGR->AddScroll(L"back.4", { 850.0f, 110.0f });
	MAP_MGR->AddScroll(L"back.7", { 900.0f, 30.0f });
	MAP_MGR->AddScroll(L"back.2", { 1050.0f, 50.0f });
	MAP_MGR->AddScroll(L"back.6", { 1000.0f, 120.0f });

	// ��� 2

	m_LayOut2_Size = { 1400, 850 };

	MAP_MGR->AddBackGround2(L"back.9",	{ 201.0f,  368.0f });
	MAP_MGR->AddBackGround2(L"back.9", { 600.5f,   368.0f });
	MAP_MGR->AddBackGround2(L"back.9",	{ 1000.0f, 368.0f });
	MAP_MGR->AddBackGround2(L"back.9", { 1400.0f,  368.0f });

	// ��� 3

	m_LayOut3_Size = { 1600, 900 };

	MAP_MGR->AddBackGround3(L"back.11", { 401.0f,  726.0f });
	MAP_MGR->AddBackGround3(L"back.12", { 1200.5f, 726.0f });
	MAP_MGR->AddBackGround3(L"back.13", { 2000.0f, 726.0f });

	// ��� 4

	m_LayOut4_Size = { 1600, 1000 };

	MAP_MGR->AddBackGround4(L"back.14", { 401.0f,  798.0f });
	MAP_MGR->AddBackGround4(L"back.15", { 1200.5f, 798.0f });
	MAP_MGR->AddBackGround4(L"back.16", { 2000.0f, 798.0f });

	// ��� 5

	m_LayOut5_Size = { 1800, 1100 };

	MAP_MGR->AddBackGround5(L"back.18", { 401.0f,  988.0f });
	MAP_MGR->AddBackGround5(L"back.19", { 1200.5f, 988.0f });
	MAP_MGR->AddBackGround5(L"back.20", { 2000.0f, 988.0f });

	// ��� 6

	m_LayOut6_Size = { 2000, 1200 };

	MAP_MGR->AddBackGround6(L"nature.11.0", { 150.0f, 995.0f });
	MAP_MGR->AddBackGround6(L"nature.0.0", { 0.0f,    995.0f });
	MAP_MGR->AddBackGround6(L"nature.10.0", { 50.0f,  995.0f });

	// Holybird
	MAP_MGR->AddBackGround6(L"holybird.0.0", { 1301.0f, 995.0f });
	MAP_MGR->AddBackGround6(L"holybird.1.0", { 1393.5f, 1000.0f });
	MAP_MGR->AddBackGround6(L"holybird.4.0", { 1513.0f, 996.0f });

	// Ÿ�� _ ���̽�

	MAP_MGR->AddFlatTileH({ 0, 1018 }, 30, true);
	MAP_MGR->AddFlatTileM({ 0, 1048 }, 30);
	MAP_MGR->AddFlatTileM({ 0, 1108 }, 30);
	MAP_MGR->AddFlatTileM({ 0, 1168 }, 30);


	// ������ Ÿ��

	MAP_MGR->AddFlatTileH({ 300, 518 }, 3);
	MAP_MGR->AddFlatTileL({ 300, 518 }, 3);


	// ���� �ִϸ��̼� �����

	// ��Ʈ�� �̸� ����Ʈ
	vector<wstring> holybirdImgList;

	holybirdImgList.push_back(L"holybird.17.0");
	holybirdImgList.push_back(L"holybird.17.1");
	holybirdImgList.push_back(L"holybird.17.2");


	// ��ġ, �� Ÿ��, �ִϸ��̼� �ð� ����, ��Ʈ�� ����Ʈ(����)
	MAP_MGR->AddAnimation({ 650.0f, 985.0f }, MAP_BACKGROUND6, 0.2f, holybirdImgList);

	// ����

	MAP_MGR->AddLadder(L"0.0.0", { 400, 520 }, true);
	MAP_MGR->AddLadder(L"0.3.0", { 396, 640 }, false);
	MAP_MGR->AddLadder(L"0.3.0", { 396, 760 }, false);
	MAP_MGR->AddLadder(L"0.3.0", { 396, 880 }, false);



	// ��Ż

	vector<wstring> portalImgList;
	portalImgList.push_back(L"pv.default.1");
	portalImgList.push_back(L"pv.default.2");
	portalImgList.push_back(L"pv.default.3");
	portalImgList.push_back(L"pv.default.4");
	portalImgList.push_back(L"pv.default.5");
	portalImgList.push_back(L"pv.default.6");
	portalImgList.push_back(L"pv.default.7");


	MAP_MGR->AddPortal(1, { 320, 493 }, portalImgList, MNAME_ARCANA, 2);

	MAP_MGR->AddPortal(2, { 320, 991 }, portalImgList, MNAME_ARCANA, 1);

	MAP_MGR->AddPortal(3, { 500, 493 }, portalImgList, MNAME_ARCANA, 3);

	
	///// ���̾ƿ� ī�޶� ���� ����

	m_LayOut2.m_Transform.m_isCamera = true;
	m_LayOut3.m_Transform.m_isCamera = true;
	m_LayOut4.m_Transform.m_isCamera = true;
	m_LayOut5.m_Transform.m_isCamera = true;
	m_LayOut6.m_Transform.m_isCamera = true;

	m_LayOut2.m_Transform.m_CameraRate.x = (m_LayOut2_Size.x - WIN_WIDTH) / (m_LayOut6_Size.x - WIN_WIDTH);
	m_LayOut3.m_Transform.m_CameraRate.x = (m_LayOut3_Size.x - WIN_WIDTH) / (m_LayOut6_Size.x - WIN_WIDTH);
	m_LayOut4.m_Transform.m_CameraRate.x = (m_LayOut4_Size.x - WIN_WIDTH) / (m_LayOut6_Size.x - WIN_WIDTH);
	m_LayOut5.m_Transform.m_CameraRate.x = (m_LayOut5_Size.x - WIN_WIDTH) / (m_LayOut6_Size.x - WIN_WIDTH);
	m_LayOut6.m_Transform.m_CameraRate.x = (m_LayOut6_Size.x - WIN_WIDTH) / (m_LayOut6_Size.x - WIN_WIDTH);

	m_LayOut2.m_Transform.m_CameraRate.y = (m_LayOut2_Size.y - WIN_HEIGHT) / (m_LayOut6_Size.y - WIN_HEIGHT);
	m_LayOut3.m_Transform.m_CameraRate.y = (m_LayOut3_Size.y - WIN_HEIGHT) / (m_LayOut6_Size.y - WIN_HEIGHT);
	m_LayOut4.m_Transform.m_CameraRate.y = (m_LayOut4_Size.y - WIN_HEIGHT) / (m_LayOut6_Size.y - WIN_HEIGHT);
	m_LayOut5.m_Transform.m_CameraRate.y = (m_LayOut5_Size.y - WIN_HEIGHT) / (m_LayOut6_Size.y - WIN_HEIGHT);
	m_LayOut6.m_Transform.m_CameraRate.y = (m_LayOut6_Size.y - WIN_HEIGHT) / (m_LayOut6_Size.y - WIN_HEIGHT);
}


