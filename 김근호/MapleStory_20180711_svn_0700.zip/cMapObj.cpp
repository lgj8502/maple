#include "stdafx.h"
#include "cMapObj.h"


cMapObj::cMapObj()
{
}


cMapObj::~cMapObj()
{
}
