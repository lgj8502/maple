#include "stdafx.h"
#include "CreateScene1.h"


//////�߰� ����
static bool checkEvent = false;
//////////////////

CreateScene1::~CreateScene1()
{
}

void CreateScene1::Init(HWND hWnd)
{
	IMG_MGR->FileFindDir(L".\\Img\\CreateScene1\\");
	SOUND_MGR->FileFindDir(L".\\Sound\\");

	//	mouse default image 
	obj.m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mouseDefault"));	//0
	obj.m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mouseClick"));		// 1

	//mouse animation
	obj.m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mouseOver0"));		// 2
	obj.m_Renderer.AddBitmap(IMG_MGR->GetImage(L"mouseOver1"));		// 3
	obj.m_Renderer.AddAnimation(0, 2, 3, 0.5, 0.5);
	obj.m_Renderer.m_State = -1;
	//////////////////////////////////////////////
	//BackGround
	UI_MGR->AddImage("CreateScene1_Background", L"CreateScene1_Background", { 0,0,1200,800 });
	//////////////////////////////////////////////
	//Menu
	UI_MGR->AddImage("CreateScene1_Menu", L"CreateScene1_Menu", { 884,411 }, { 1.5f, 1.33333f });
	UI_MGR->FindUI("CreateScene1_Menu")->m_isActive = false;
	//////////////////////////////////////////////
	 // arrow  
	// 1 y :: -101
	// 2 y :: -83
	// 3 y :: -47
	// 4 y :: -30
	// 5 y :: -13

	//1
	UI_MGR->AddButton("CreateScene1_LeftArrow_default1", L"CreateScene1_LeftArrow_default", { -43,-101 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_LeftArrow_default1")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_LeftArrow_default1", L"CreateScene1_LeftArrow_Over");
	auto CreateScene1Func_Menu_Arrow1 = [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default1")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow2 = [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default1")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default1", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow1);
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default1", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow2);

	UI_MGR->AddButton("CreateScene_RightArrow_default1", L"CreateScene_RightArrow_default", { 73,-101 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene_RightArrow_default1")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene_RightArrow_default1", L"CreateScene_RightArrow_Over");
	auto CreateScene1Func_Menu_Arrow3 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default1")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow4 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default1")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene_RightArrow_default1", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow3);
	UI_MGR->AddEvent("CreateScene_RightArrow_default1", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow4);

	//2
	UI_MGR->AddButton("CreateScene1_LeftArrow_default2", L"CreateScene1_LeftArrow_default", { -43,-83 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_LeftArrow_default2")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_LeftArrow_default2", L"CreateScene1_LeftArrow_Over");
	auto CreateScene1Func_Menu_Arrow5 = [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default2")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow6 = [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default2")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default2", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow5);
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default2", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow6);

	UI_MGR->AddButton("CreateScene_RightArrow_default2", L"CreateScene_RightArrow_default", { 73,-83 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene_RightArrow_default2")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene_RightArrow_default2", L"CreateScene_RightArrow_Over");
	auto CreateScene1Func_Menu_Arrow7 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default2")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow8 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default2")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene_RightArrow_default2", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow7);
	UI_MGR->AddEvent("CreateScene_RightArrow_default2", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow8);

	//3
	UI_MGR->AddButton("CreateScene1_LeftArrow_default3", L"CreateScene1_LeftArrow_default", { -43,-47 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_LeftArrow_default3")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_LeftArrow_default3", L"CreateScene1_LeftArrow_Over");
	auto CreateScene1Func_Menu_Arrow9 = [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default3")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow10 = [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default3")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default3", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow9);
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default3", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow10);

	UI_MGR->AddButton("CreateScene_RightArrow_default3", L"CreateScene_RightArrow_default", { 73,-47 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene_RightArrow_default3")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene_RightArrow_default3", L"CreateScene_RightArrow_Over");
	auto CreateScene1Func_Menu_Arrow11 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default3")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow12 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default3")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene_RightArrow_default3", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow11);
	UI_MGR->AddEvent("CreateScene_RightArrow_default3", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow12);

	//4
	UI_MGR->AddButton("CreateScene1_LeftArrow_default4", L"CreateScene1_LeftArrow_default", { -43,-30 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_LeftArrow_default4")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_LeftArrow_default4", L"CreateScene1_LeftArrow_Over");
	auto CreateScene1Func_Menu_Arrow13 = [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default4")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow14 = [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default4")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default4", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow13);
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default4", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow14);

	UI_MGR->AddButton("CreateScene_RightArrow_default4", L"CreateScene_RightArrow_default", { 73,-30 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene_RightArrow_default4")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene_RightArrow_default4", L"CreateScene_RightArrow_Over");
	auto CreateScene1Func_Menu_Arrow15 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default4")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow16 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default4")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene_RightArrow_default4", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow15);
	UI_MGR->AddEvent("CreateScene_RightArrow_default4", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow16);

	//5
	UI_MGR->AddButton("CreateScene1_LeftArrow_default5", L"CreateScene1_LeftArrow_default", { -43,-13 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_LeftArrow_default5")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_LeftArrow_default5", L"CreateScene1_LeftArrow_Over");
	auto CreateScene1Func_Menu_Arrow17= [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default5")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow18 = [](void) { UI_MGR->FindUI("CreateScene1_LeftArrow_default5")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default5", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow17);
	UI_MGR->AddEvent("CreateScene1_LeftArrow_default5", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow18);

	UI_MGR->AddButton("CreateScene_RightArrow_default5", L"CreateScene_RightArrow_default", { 73,-13 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene_RightArrow_default5")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene_RightArrow_default5", L"CreateScene_RightArrow_Over");
	auto CreateScene1Func_Menu_Arrow19 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default5")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_Menu_Arrow20 = [](void) { UI_MGR->FindUI("CreateScene_RightArrow_default5")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene_RightArrow_default5", ADDEVENT_OnMouseOver, CreateScene1Func_Menu_Arrow19);
	UI_MGR->AddEvent("CreateScene_RightArrow_default5", ADDEVENT_OnMouseExit, CreateScene1Func_Menu_Arrow20);
	// arrow end
	//////////////////////////////////////////////
	//////////////////////////////////////////////
	// ColorBox
	UI_MGR->AddButton("CreateScene1_Color_Black_default", L"CreateScene1_Color_Black_default", { -37,-66 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_Color_Black_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_Color_Black_default", L"CreateScene1_Color_Black_Over");
	auto CreateScene1Func_ColorBlackDefault = [](void) { UI_MGR->FindUI("CreateScene1_Color_Black_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_ColorBlackOver = [](void) { UI_MGR->FindUI("CreateScene1_Color_Black_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_Color_Black_default", ADDEVENT_OnMouseOver, CreateScene1Func_ColorBlackDefault);
	UI_MGR->AddEvent("CreateScene1_Color_Black_default", ADDEVENT_OnMouseExit, CreateScene1Func_ColorBlackOver);

	UI_MGR->AddButton("CreateScene1_Color_Red_default", L"CreateScene1_Color_Red_default", { -22,-66 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_Color_Red_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_Color_Red_default", L"CreateScene1_Color_Red_Over");
	auto CreateScene1Func_ColorRedDefault = [](void) { UI_MGR->FindUI("CreateScene1_Color_Red_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_ColorRedOver = [](void) { UI_MGR->FindUI("CreateScene1_Color_Red_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_Color_Red_default", ADDEVENT_OnMouseOver, CreateScene1Func_ColorRedDefault);
	UI_MGR->AddEvent("CreateScene1_Color_Red_default", ADDEVENT_OnMouseExit, CreateScene1Func_ColorRedOver);

	UI_MGR->AddButton("CreateScene1_Color_Orange_default", L"CreateScene1_Color_Orange_default", { -7,-66 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_Color_Orange_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_Color_Orange_default", L"CreateScene1_Color_Orange_Over");
	auto CreateScene1Func_ColorOrangeDefault = [](void) { UI_MGR->FindUI("CreateScene1_Color_Orange_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_ColorOrangeOver = [](void) { UI_MGR->FindUI("CreateScene1_Color_Orange_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_Color_Orange_default", ADDEVENT_OnMouseOver, CreateScene1Func_ColorOrangeDefault);
	UI_MGR->AddEvent("CreateScene1_Color_Orange_default", ADDEVENT_OnMouseExit, CreateScene1Func_ColorOrangeOver);

	UI_MGR->AddButton("CreateScene1_Color_Yellow_default", L"CreateScene1_Color_Yellow_default", { 8,-66 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_Color_Yellow_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_Color_Yellow_default", L"CreateScene1_Color_Yellow_Over");
	auto CreateScene1Func_ColorYellowDefault = [](void) { UI_MGR->FindUI("CreateScene1_Color_Yellow_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_ColorYellowOver = [](void) { UI_MGR->FindUI("CreateScene1_Color_Yellow_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_Color_Yellow_default", ADDEVENT_OnMouseOver, CreateScene1Func_ColorYellowDefault);
	UI_MGR->AddEvent("CreateScene1_Color_Yellow_default", ADDEVENT_OnMouseExit, CreateScene1Func_ColorYellowOver);

	UI_MGR->AddButton("CreateScene1_Color_Green_default", L"CreateScene1_Color_Green_default", { 23,-66 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_Color_Green_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_Color_Green_default", L"CreateScene1_Color_Green_Over");
	auto CreateScene1Func_ColorGreenDefault = [](void) { UI_MGR->FindUI("CreateScene1_Color_Green_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_ColorGreenOver = [](void) { UI_MGR->FindUI("CreateScene1_Color_Green_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_Color_Green_default", ADDEVENT_OnMouseOver, CreateScene1Func_ColorGreenDefault);
	UI_MGR->AddEvent("CreateScene1_Color_Green_default", ADDEVENT_OnMouseExit, CreateScene1Func_ColorGreenOver);

	UI_MGR->AddButton("CreateScene1_Color_Blue_default", L"CreateScene1_Color_Blue_default", { 38,-66 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_Color_Blue_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_Color_Blue_default", L"CreateScene1_Color_Blue_Over");
	auto CreateScene1Func_ColorBlueDefault = [](void) { UI_MGR->FindUI("CreateScene1_Color_Blue_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_ColorBlueOver = [](void) { UI_MGR->FindUI("CreateScene1_Color_Blue_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_Color_Blue_default", ADDEVENT_OnMouseOver, CreateScene1Func_ColorBlueDefault);
	UI_MGR->AddEvent("CreateScene1_Color_Blue_default", ADDEVENT_OnMouseExit, CreateScene1Func_ColorBlueOver);

	UI_MGR->AddButton("CreateScene1_Color_Purple_default", L"CreateScene1_Color_Purple_default", { 53,-66 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_Color_Purple_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_Color_Purple_default", L"CreateScene1_Color_Purple_Over");
	auto CreateScene1Func_ColorPurpleDefault = [](void) { UI_MGR->FindUI("CreateScene1_Color_Purple_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_ColorPurpleOver = [](void) { UI_MGR->FindUI("CreateScene1_Color_Purple_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_Color_Purple_default", ADDEVENT_OnMouseOver, CreateScene1Func_ColorPurpleDefault);
	UI_MGR->AddEvent("CreateScene1_Color_Purple_default", ADDEVENT_OnMouseExit, CreateScene1Func_ColorPurpleOver);

	UI_MGR->AddButton("CreateScene1_Color_Brown_default", L"CreateScene1_Color_Brown_default", { 68,-66 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("CreateScene1_Color_Brown_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_Color_Brown_default", L"CreateScene1_Color_Brown_Over");
	auto CreateScene1Func_ColorBrownDefault = [](void) { UI_MGR->FindUI("CreateScene1_Color_Brown_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_ColorBrownOver = [](void) { UI_MGR->FindUI("CreateScene1_Color_Brown_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_Color_Brown_default", ADDEVENT_OnMouseOver, CreateScene1Func_ColorBrownDefault);
	UI_MGR->AddEvent("CreateScene1_Color_Brown_default", ADDEVENT_OnMouseExit, CreateScene1Func_ColorBrownOver);

	// ColorBox end
	//////////////////////////////////////////////
	//////////////////////////////////////////////
	//				�θ���
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_LeftArrow_default1");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene_RightArrow_default1");

	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_LeftArrow_default2");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene_RightArrow_default2");

	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_LeftArrow_default3");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene_RightArrow_default3");

	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_LeftArrow_default4");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene_RightArrow_default4");

	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_LeftArrow_default5");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene_RightArrow_default5");

	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_Color_Black_default");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_Color_Red_default");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_Color_Orange_default");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_Color_Yellow_default");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_Color_Green_default");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_Color_Blue_default");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_Color_Purple_default");
	UI_MGR->SetParent("CreateScene1_Menu", "CreateScene1_Color_Brown_default");
	//				�θ��� end
	//////////////////////////////////////////////
	//////////////////////////////////////////////
	//MaleSelect
	UI_MGR->AddButton("CreateScene1_MaleSelect_default", L"CreateScene1_MaleSelect_default", { 820,355 }, { 1.5f, 1.33333f });
	UI_MGR->FindUI("CreateScene1_MaleSelect_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_MaleSelect_default", L"CreateScene1_MaleSelect_Over");
	auto CreateScene1Func_MaleSelect0 = [](void) { UI_MGR->FindUI("CreateScene1_MaleSelect_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func_MaleSelect1 = [](void) { UI_MGR->FindUI("CreateScene1_MaleSelect_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	auto CreateScene1Func_MaleSelect2 = [](void) { 
	UI_MGR->FindUI("CreateScene1_MaleSelect_default")->m_isActive = false;
	UI_MGR->FindUI("CreateScene1_Menu")->m_isActive = true;
	UI_MGR->FindUI("CreateScene1_Ok1_default")->m_Transform.SetPos(831, 519);
	UI_MGR->FindUI("CreateScene1_No1_default")->m_Transform.SetPos(942, 520);
	};
	UI_MGR->AddEvent("CreateScene1_MaleSelect_default", ADDEVENT_OnMouseOver, CreateScene1Func_MaleSelect0);
	UI_MGR->AddEvent("CreateScene1_MaleSelect_default", ADDEVENT_OnMouseExit, CreateScene1Func_MaleSelect1);
	UI_MGR->AddEvent("CreateScene1_MaleSelect_default", ADDEVENT_OnMouseClick, CreateScene1Func_MaleSelect2);

	//Ȯ��
	UI_MGR->AddButton("CreateScene1_Ok1_default", L"CreateScene1_Ok1_default", { 831,552 }, { 1.5f, 1.33333f });
	UI_MGR->FindUI("CreateScene1_Ok1_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_Ok1_default", L"CreateScene1_Ok1_Over");
	auto CreateScene1Func2 = [](void) { UI_MGR->FindUI("CreateScene1_Ok1_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1Func3 = [](void) { UI_MGR->FindUI("CreateScene1_Ok1_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("CreateScene1_Ok1_default", ADDEVENT_OnMouseOver, CreateScene1Func2);
	UI_MGR->AddEvent("CreateScene1_Ok1_default", ADDEVENT_OnMouseExit, CreateScene1Func3);
	
	//���
	UI_MGR->AddButton("CreateScene1_No1_default", L"CreateScene1_No1_default", { 943,552 }, { 1.5f, 1.33333f });
	UI_MGR->FindUI("CreateScene1_No1_default")->m_RayCast = true;
	UI_MGR->BitMapAdd("CreateScene1_No1_default", L"CreateScene1_No1_Over");
	auto CreateScene1_No0 = [](void) { UI_MGR->FindUI("CreateScene1_No1_default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene1_No1 = [](void) { UI_MGR->FindUI("CreateScene1_No1_default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	auto CreateScene1_No2 = [](void) { 
		if (UI_MGR->FindUI("CreateScene1_Menu")->m_isActive == true)
		{
			UI_MGR->FindUI("CreateScene1_Menu")->m_isActive = false;
			UI_MGR->FindUI("CreateScene1_MaleSelect_default")->m_isActive = true;
			UI_MGR->FindUI("CreateScene1_Ok1_default")->m_Transform.SetPos(831, 552);
			UI_MGR->FindUI("CreateScene1_No1_default")->m_Transform.SetPos(943, 552);
		}
	};
	UI_MGR->AddEvent("CreateScene1_No1_default", ADDEVENT_OnMouseOver, CreateScene1_No0);
	UI_MGR->AddEvent("CreateScene1_No1_default", ADDEVENT_OnMouseExit, CreateScene1_No1);
	UI_MGR->AddEvent("CreateScene1_No1_default", ADDEVENT_OnMouseClick, CreateScene1_No2);









	//��������
	UI_MGR->AddButton("ChannelReturn_Default", L"LobbyScene_ChannelReturn_Default", { 59,694 }, { 1.50f, 1.33333f });
	UI_MGR->FindUI("ChannelReturn_Default")->m_RayCast = true;
	UI_MGR->BitMapAdd("ChannelReturn_Default", L"LobbyScene_ChannelReturn_Over");
	auto CreateScene0_Func10 = [](void) { UI_MGR->FindUI("ChannelReturn_Default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene0_Func11 = [](void) { UI_MGR->FindUI("ChannelReturn_Default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("ChannelReturn_Default", ADDEVENT_OnMouseOver, CreateScene0_Func10);
	UI_MGR->AddEvent("ChannelReturn_Default", ADDEVENT_OnMouseExit, CreateScene0_Func11);
	auto CreateScene0_Func16 = [](void) {SCENE_MGR->ChangeScene(SCENE_CREATE0); };
	UI_MGR->AddEvent("ChannelReturn_Default", ADDEVENT_OnMouseClick, CreateScene0_Func16);


	//ó������
	UI_MGR->AddButton("returnLogin_Default", L"ChannelScene_returnLogin_Default", { 59,747 }, { 1.50f, 1.33333f });
	UI_MGR->FindUI("returnLogin_Default")->m_RayCast = true;
	UI_MGR->BitMapAdd("returnLogin_Default", L"ChannelScene_returnLogin_Over");
	auto CreateScene0_Func8 = [](void) { UI_MGR->FindUI("returnLogin_Default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene0_Func9 = [](void) { UI_MGR->FindUI("returnLogin_Default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("returnLogin_Default", ADDEVENT_OnMouseOver, CreateScene0_Func8);
	UI_MGR->AddEvent("returnLogin_Default", ADDEVENT_OnMouseExit, CreateScene0_Func9);


	UI_MGR->AddButton("returnPage", L"ChannelScene_returnPage", { 600,400 }, { 1.50f, 1.33333f });

	UI_MGR->AddButton("returnPage_no_Default", L"ChannelScene_returnPage_no_Default", { 30,47 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("returnPage_no_Default")->m_RayCast = true;
	UI_MGR->BitMapAdd("returnPage_no_Default", L"ChannelScene_returnPage_no_Over");
	auto CreateScene0_Func1 = [](void) { UI_MGR->FindUI("returnPage_no_Default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene0_Func2 = [](void) { UI_MGR->FindUI("returnPage_no_Default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("returnPage_no_Default", ADDEVENT_OnMouseOver, CreateScene0_Func1);
	UI_MGR->AddEvent("returnPage_no_Default", ADDEVENT_OnMouseExit, CreateScene0_Func2);

	UI_MGR->AddButton("returnPage_ok_Default", L"ChannelScene_returnPage_ok_Default", { -30,47 }, { 1.0f, 1.0 });
	UI_MGR->FindUI("returnPage_ok_Default")->m_RayCast = true;
	UI_MGR->BitMapAdd("returnPage_ok_Default", L"ChannelScene_returnPage_ok_Over");
	auto CreateScene0_Func3 = [](void) { UI_MGR->FindUI("returnPage_ok_Default")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto CreateScene0_Func4 = [](void) { UI_MGR->FindUI("returnPage_ok_Default")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("returnPage_ok_Default", ADDEVENT_OnMouseOver, CreateScene0_Func3);
	UI_MGR->AddEvent("returnPage_ok_Default", ADDEVENT_OnMouseExit, CreateScene0_Func4);
	UI_MGR->SetParent("returnPage", "returnPage_no_Default");
	UI_MGR->SetParent("returnPage", "returnPage_ok_Default");
	UI_MGR->FindUI("returnPage")->m_isActive = false;
	auto CreateScene0_Func5 = [](void) { UI_MGR->FindUI("returnPage")->m_isActive = true; };
	UI_MGR->AddEvent("returnLogin_Default", ADDEVENT_OnMouseClick, CreateScene0_Func5);
	auto CreateScene0_Func6 = [](void) { UI_MGR->FindUI("returnPage")->m_isActive = false; };
	UI_MGR->AddEvent("returnPage_no_Default", ADDEVENT_OnMouseClick, CreateScene0_Func6);
	auto CreateScene0_Func7 = [](void) {SCENE_MGR->ChangeScene(SCENE_LOGIN); };
	UI_MGR->AddEvent("returnPage_ok_Default", ADDEVENT_OnMouseClick, CreateScene0_Func7);


	//============================================================================================
	//���� ���� â
	UI_MGR->AddButton("gameEnd", L"Game_End", { 600,400 }, { 1.50f, 1.33333f });

	// ��� ��ư
	UI_MGR->AddButton("gameEnd_No", L"ChannelScene_returnPage_no_Default", { 30,47 }, { 1.0f, 1.0f });
	UI_MGR->FindUI("gameEnd_No")->m_RayCast = true;
	UI_MGR->BitMapAdd("gameEnd_No", L"ChannelScene_returnPage_no_Over");
	auto End_Func0 = [](void) { UI_MGR->FindUI("gameEnd_No")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto End_Func1 = [](void) { UI_MGR->FindUI("gameEnd_No")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("gameEnd_No", ADDEVENT_OnMouseOver, End_Func0);
	UI_MGR->AddEvent("gameEnd_No", ADDEVENT_OnMouseExit, End_Func1);

	// Ȯ�� ��ư
	UI_MGR->AddButton("gameEnd_Ok", L"ChannelScene_returnPage_ok_Default", { -30,47 }, { 1.0f, 1.0 });
	UI_MGR->FindUI("gameEnd_Ok")->m_RayCast = true;
	UI_MGR->BitMapAdd("gameEnd_Ok", L"ChannelScene_returnPage_ok_Over");
	auto End_Func2 = [](void) { UI_MGR->FindUI("gameEnd_Ok")->m_Renderer.ChangeBitmap(1); checkEvent = true; };
	auto End_Func3 = [](void) { UI_MGR->FindUI("gameEnd_Ok")->m_Renderer.ChangeBitmap(0);  checkEvent = false; };
	UI_MGR->AddEvent("gameEnd_Ok", ADDEVENT_OnMouseOver, End_Func2);
	UI_MGR->AddEvent("gameEnd_Ok", ADDEVENT_OnMouseExit, End_Func3);

	// �θ� ����
	UI_MGR->SetParent("gameEnd", "gameEnd_No");
	UI_MGR->SetParent("gameEnd", "gameEnd_Ok");
	// �ʱⰪ �Ⱥ��̰�
	UI_MGR->FindUI("gameEnd")->m_isActive = false;

	//���� ���� ��� �̺�Ʈ
	auto End_Func5 = [](void) { UI_MGR->FindUI("gameEnd")->m_isActive = false; };
	UI_MGR->AddEvent("gameEnd_No", ADDEVENT_OnMouseClick, End_Func5);
	//���� ���� Ȯ�� �̺�Ʈ
	auto End_Func6 = [](void) {PostQuitMessage(WM_DESTROY); };
	UI_MGR->AddEvent("gameEnd_Ok", ADDEVENT_OnMouseClick, End_Func6);
	//============
}

void CreateScene1::Update(float _DelayTime)
{
	if (UI_MGR->m_ExitField == true)
	{
		m_szBuf = "";
		m_szMixingString[0] = NULL;

		UI_MGR->m_ExitField = false;

	}

	UI_MGR->Update(_DelayTime);

	//m_player.Update(_DelayTime);
	obj.Update(_DelayTime);

	if (GetAsyncKeyState(VK_RETURN) & 0x8000)
	{
		if (UI_MGR->m_isChating == false)
		{
			UI_MGR->m_isChating = true;
		}
	}
}

void CreateScene1::Render()
{
	UI_MGR->Render();

	//m_player.Render();
	obj.Render();
}

void CreateScene1::SendText()
{
	if (UI_MGR->m_InputField->m_SonUI[0]->m_isTyping == false)
	{
		m_oldText = UI_MGR->m_InputField->m_SonUI[0]->m_Text;

		string temp = m_szBuf;

		m_szBuf = m_oldText + temp;

		UI_MGR->m_InputField->m_SonUI[0]->m_isTyping = true;
	}

	string sText = m_szBuf + m_szMixingString;

	UI_MGR->m_InputField->m_SonUI[0]->m_Text = sText;
}

LRESULT CreateScene1::MyWndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage)
	{
		//case WM_SETCURSOR: SetCursor(NULL); break;

	case WM_MOUSEMOVE:
	{
		m_MousePos.x = GET_X_LPARAM(lParam);
		m_MousePos.y = GET_Y_LPARAM(lParam);

		obj.m_Transform.SetPos((float)m_MousePos.x + 14.0f, (float)m_MousePos.y + 2.0f);

		if (checkEvent)
		{
			obj.m_Renderer.m_State = 0;
		}
		else
		{
			obj.m_Renderer.m_State = -1;
			obj.m_Renderer.ChangeBitmap(0);
		}

		if (m_isClicked == true)
		{
			UI_MGR->OnMouseDrag(m_MousePos);
		}
		else
		{
			UI_MGR->OnMouseOver(m_MousePos);
			UI_MGR->OnMouseExit(m_MousePos);
		}

	}break;

	case WM_LBUTTONDOWN:
	{
		SOUND_MGR->SoundResume(L"btMouseClick");
		obj.m_Renderer.m_State = -1;
		obj.m_Renderer.ChangeBitmap(1);
		MK_LOG("%d, %d Ŭ��", m_MousePos.x, m_MousePos.y);

		UI_MGR->OnMouseDown(m_MousePos);

		m_isClicked = true;

	}break;

	case WM_LBUTTONUP:
	{
		//obj.m_Renderer.ChangeBitmap(0);
		if (checkEvent)
		{
			obj.m_Renderer.m_State = 0;
			//obj.m_Renderer.AddAnimation(PLAYER_IDLE, 2, 3, 0.5, 0.5);

		}
		else
		{
			obj.m_Renderer.m_State = -1;
			obj.m_Renderer.ChangeBitmap(0);
		}
		UI_MGR->OnMouseUp(m_MousePos);

		m_isClicked = false;

	}break;

	case WM_MOUSEWHEEL:
	{
		SCENE_MGR->ChangeScene(SCENE_CHANNEL);
	}break;
	// IME ��

	case WM_CHAR:
	{
		if (UI_MGR->m_isChating == false) break;


		char cWord = (char)wParam;

		//	�齺���̽� ��ư Ŭ��
		if (cWord == VK_BACK &&
			m_szMixingString[0] == NULL)
		{
			int nLen = m_szBuf.length();

			if (nLen > 0)
			{
				//	�������� ���ڰ� ����ü �ΰ��
				if (m_szBuf[nLen - 1] < 0)
				{
					m_szBuf = m_szBuf.substr(0, nLen - 2);
				}

				//	�Ϲ� ���ڸ� ���� ���
				else
				{
					m_szBuf = m_szBuf.substr(0, nLen - 1);
				}
			}
		}
		//	����
		else if (cWord == VK_RETURN)
		{
			//CheckText = m_szBuf;
			m_szBuf = "";
			m_szMixingString[0] = NULL;

			m_oldText = "";

			UI_MGR->m_InputField->m_SonUI[0]->m_Text = "";

		}
		else
		{
			if (m_szBuf.size() > m_maxText)
			{
				break;
			}

			m_szBuf += (char)wParam;
		}

		SendText();


	}break;

	//	������ ������ ���� ��� �������� ���ڿ��� ����.
	case WM_IME_ENDCOMPOSITION:
	{
		if (UI_MGR->m_isChating == false) break;

		if (m_szBuf.size() >= m_maxText)
		{
			break;
		}

		m_szMixingString[0] = NULL;

		SendText();
	}
	break;

	//	IME �ȿ� �ִ� ���տ� ���� ������ ���� �� �ִ�.
	case WM_IME_COMPOSITION:
	{
		if (UI_MGR->m_isChating == false) break;

		if (m_szBuf.size() >= m_maxText)
		{
			break;
		}
		//	�������� ��� ���� �������� �ܾ ���´�.
		if (lParam & GCS_COMPSTR)
		{
			m_szMixingString[0] = CHAR(wParam >> 8);
			m_szMixingString[1] = CHAR(wParam);
		}

		//	������ ���� ���	WM_IME_CHAR �� ���� ��Ȱ
		else if (lParam & GCS_RESULTSTR)
		{
			char szFinalString[3];

			szFinalString[0] = CHAR(wParam >> 8);
			szFinalString[1] = CHAR(wParam);
			szFinalString[2] = NULL;

			//	�ϼ��� ���ڿ��� �߰� �Ѵ�.
			m_szBuf += szFinalString;
		}
		SendText();
		//	�⺻ IME ���� �������� �ʱ� ���� �ٷ� ���ν����� ������.
		return 0;
	}
	break;
	//==================================================================================================
	// ���� ����
	case WM_CLOSE:
		UI_MGR->FindUI("gameEnd")->m_isActive = true;
		return 0;
		/*default:
		return FALSE;*/
		//====
	}



	return (DefWindowProcA(hWnd, iMessage, wParam, lParam));
}

