#pragma once
class cErebMap : public cMap
{
public:

	~cErebMap();

	void Init();

};

