#pragma once
class cEffect
{
public:
	cEffect();
	~cEffect();
};

