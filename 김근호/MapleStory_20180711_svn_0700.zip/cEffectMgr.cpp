#include "stdafx.h"
#include "cEffectMgr.h"


cEffectMgr::~cEffectMgr()
{
}
