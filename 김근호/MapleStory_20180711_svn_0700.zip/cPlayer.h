#pragma once
class cPlayer : public Object2D
{
public:
	cPlayer();
	~cPlayer();
};

